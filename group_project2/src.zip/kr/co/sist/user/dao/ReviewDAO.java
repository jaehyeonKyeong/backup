package kr.co.sist.user.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import kr.co.sist.properties.DataBaseConnection;
import kr.co.sist.user.vo.ReviewContentVO;
import kr.co.sist.user.vo.ReviewVO;

public class ReviewDAO {
	private static ReviewDAO r_dao;
	private ReviewDAO() {
		
	}
	public static ReviewDAO getInstance() {
		if(r_dao==null) {
			r_dao=new ReviewDAO();
		}
		return r_dao;
	}
	public static Connection getConnection() throws SQLException {
		Connection con = null;
		DataBaseConnection dbc = DataBaseConnection.getInstance();
		String driver = dbc.getDriver();
		String url = dbc.getUrl();
		String id = dbc.getId();
		String pass = dbc.getPass();
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		con = DriverManager.getConnection(url, id, pass);
		return con;
	}
	public List<ReviewVO> selectRankReview(String rNum) throws SQLException{
		List<ReviewVO> reviewList=new ArrayList<>();
		
		Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			con=getConnection();
			String selectSql="select r.review_number,r.review_contents, r.ID, r.REVIEW_TITLE, l.LIKE_NUMBER,r.restaurant_number from review r,review_like l where r.restaurant_number=l.restaurant_number and trim(r.restaurant_number)=? order by like_number desc";
			pstmt=con.prepareStatement(selectSql);
			pstmt.setString(1, rNum.trim());
			rs=pstmt.executeQuery();
			ReviewVO rvo=null;
			while(rs.next()) {
				rvo=new ReviewVO(rs.getString("review_number"), rs.getString("review_contents"), rs.getString("iD"), rs.getString("rEVIEW_TITLE"), rs.getString("restaurant_number"), rs.getInt("lIKE_NUMBER"));
				reviewList.add(rvo);
			}
		}finally {
			if(rs!=null) {rs.close();}
			if(pstmt!=null) {pstmt.close();}
			if(con!=null) {con.close();}
		}
		
		return reviewList;
	}
	public List<ReviewVO> selectTodayReview(String rNum) throws SQLException {
		List<ReviewVO> reviewList=new ArrayList<>();
		
		Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			con=getConnection();
			String selectSql="select r.review_number,r.review_contents, r.ID, r.REVIEW_TITLE, l.LIKE_NUMBER,r.restaurant_number from review r,review_like l where r.restaurant_number=l.restaurant_number and trim(r.restaurant_number)=? and to_char(input_date,'yyyy-mm-dd')=to_char(sysdate,'yyyy-mm-dd') order by r.input_date desc";
			pstmt=con.prepareStatement(selectSql);
			pstmt.setString(1, rNum.trim());
			rs=pstmt.executeQuery();
			ReviewVO rvo=null;
			while(rs.next()) {
				rvo=new ReviewVO(rs.getString("review_number"), rs.getString("review_contents"), rs.getString("iD"), rs.getString("rEVIEW_TITLE"), rs.getString("restaurant_number"), rs.getInt("lIKE_NUMBER"));
				reviewList.add(rvo);
			}
		}finally {
			if(rs!=null) {rs.close();}
			if(pstmt!=null) {pstmt.close();}
			if(con!=null) {con.close();}
		}
		
		return reviewList;
	}
	//���� ��ư�� �������� �ش��ϴ� rNum�� riNum�� ������ ��õ�� ����, ����,����,�̹����� ������ �����ִ���.(VO)
	public ReviewContentVO selectGetContents(String rNum, String riNum) throws SQLException {
		ReviewContentVO rvo=null;
		Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			con=getConnection();
			String selectSql="select r.review_number, r.restaurant_number, r.id, r.review_title, r.review_contents, r.review_image, r.grades, l.like_number from review r,review_like l where r.restaurant_number(+)=l.restaurant_number and trim(r.restaurant_number)=? and trim(r.review_number)=?";
			pstmt=con.prepareStatement(selectSql);
			pstmt.setString(1, rNum.trim());
			pstmt.setString(2, riNum.trim());
			rs=pstmt.executeQuery();
			while(rs.next()) {
				rvo=new ReviewContentVO(rs.getString("review_number"), rs.getString("review_contents"), rs.getString("id"), rs.getString("review_title"), rs.getString("restaurant_number"), rs.getInt("like_number"),rs.getInt("grades"));
			}
		}finally {
			if(rs!=null) {rs.close();}
			if(pstmt!=null) {pstmt.close();}
			if(con!=null) {con.close();}
		}
		return rvo;
	}
	//review like���̺��� like_number�� �ϳ� �ø��� ��
	public void reviewthumpsUp(String rNum, String riNum) throws SQLException {
		Connection con=null;
		PreparedStatement pstmt=null;
		try {
			con=getConnection();
			String updateSql="update review_like set like_number=like_number+1 where trim(review_number)=? and trim(restaurant_number)=?";
			pstmt=con.prepareStatement(updateSql);
			pstmt.setString(1, riNum.trim());
			pstmt.setString(2, rNum.trim());
			pstmt.executeUpdate();
			
		}finally {
			if(pstmt!=null) {pstmt.close();}
			if(con!=null) {con.close();}
		}
	}
}
