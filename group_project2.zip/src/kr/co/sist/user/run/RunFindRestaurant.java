package kr.co.sist.user.run;

import kr.co.sist.user.view.Login;
public class RunFindRestaurant {

	public static void main(String[] args) {
		new Login();
	}

}
