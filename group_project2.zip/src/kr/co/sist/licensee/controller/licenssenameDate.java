package kr.co.sist.licensee.controller;

public class licenssenameDate {
	String name;

	public licenssenameDate() {
		
	}

	public licenssenameDate(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
