package day0322;
class  Hello{
	public static void main(String[] args) {
		System.out.println("Hello World!");
	}//main
}//class
