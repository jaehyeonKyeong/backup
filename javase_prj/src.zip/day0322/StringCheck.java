package day0322;
class StringCheck
{	
	public static void main(String[] args)
	{
		String strValue = "A";
		//char var = (char) strValue;
		System.out.println(strValue);
	}
}
