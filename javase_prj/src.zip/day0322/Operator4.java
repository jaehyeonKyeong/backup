package day0322;
/*
	���� ����
	>, <, >=, <=, ==, !=
*/
class Operator4 {
	public static void main(String[] args) {
		int temp1=23;
		int temp2=25;
		int temp3=23;
		System.out.println(temp1+"=="+temp3+" = "+(temp1==temp3));
		System.out.println(temp1+"=="+temp2+" = "+(temp1==temp2));
		System.out.println(temp1+"!="+temp3+" = "+(temp1!=temp3));
		System.out.println(temp1+"!="+temp2+" = "+(temp1!=temp2));


		/*
		String temp4="�ſ��";
		String temp5="�ſ��";
		String temp6="�ſ��";
		System.out.println(temp4.equals(temp5));
		System.out.println(temp4.equals(temp6));
		*/

	}//main
}//class
