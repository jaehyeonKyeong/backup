package day0322;
class Operator1 {
	public static void main(String[] args) {
		System.out.println("Hello World!");
	}
}
