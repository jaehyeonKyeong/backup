package day0321;
public class RunStatementExample{
	public static void main(String[] args){
		int x = 1;
		int y = 2;
		int result = x + y;
		System.out.println(x+"+"+y+"="+result);
	}
}
