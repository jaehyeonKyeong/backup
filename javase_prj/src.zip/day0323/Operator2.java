package day0323;


class Operator2 {
	public static void main(String[] args) {
		int birth = 1977;
		System.out.println(birth%12);

	}
}
