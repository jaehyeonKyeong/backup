package myTest0405;

public class Animal {
	public String kind;

}
