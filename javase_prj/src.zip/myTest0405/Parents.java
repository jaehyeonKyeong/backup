package myTest0405;

public class Parents {

}
