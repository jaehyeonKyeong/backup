package myTest0405;

public class Child extends Parents{

}
