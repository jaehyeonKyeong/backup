package myTest0330;

public class TestReturn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		

	}

}
