package myTest0330;

public class TestAutoGetSet {
	
	private int studentNumber;
	private String studentName;
	private char character;
	private double d;
	private boolean lateStudy;
	
	public int getStudentNumber() {
		return studentNumber;
	}
	public void setStudentNumber(int studentNumber) {
		this.studentNumber = studentNumber;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public char getCharacter() {
		return character;
	}
	public void setCharacter(char character) {
		this.character = character;
	}
	public double getD() {
		return d;
	}
	public void setD(double d) {
		this.d = d;
	}
	public boolean isLateStudy() {
		return lateStudy;
	}
	public void setLateStudy(boolean lateStudy) {
		this.lateStudy = lateStudy;
	}
	

}
