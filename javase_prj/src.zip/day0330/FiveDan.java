package day0330;

public class FiveDan {
	
	private int sum=0;
	
	public int getSum() {
		return sum;
	}
	
	public void run() {
		this.sum=0;
		for(int i=1;i<10;i++) {
			this.sum+=5*i;
	
	
		}
	}
	
	
	

}
