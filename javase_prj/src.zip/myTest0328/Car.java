package myTest0328;

public class Car {

	int speed;

	void run() {
	}

	public static void main(String[] args) {
		Car mt = new Car();
		mt.speed = 60;
		System.out.println("--------------------------------");

	}

}
