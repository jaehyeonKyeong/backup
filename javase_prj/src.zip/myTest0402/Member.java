package myTest0402;

public class Member {
	String name;
	String id;
	String password;
	int age;

	public Member(String name, String id) {
		this.name = name;
		this.id = id;

	}

	
}
