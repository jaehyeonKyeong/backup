

package myTest0402;


public class Printer {
//	public int i;
//	public boolean b;
//	public double d;
//	public String s;
	
//	public void println(int i) {
//		System.out.println(i);
//	}
//		
//	public void println(boolean b) {
//		System.out.println(b);
//	}
//	public void println(double d) {
//		System.out.println(d);
//	}
//	public void println(String s) {
//		System.out.println(s);
//	}
//	
	public static void println(int i) {
		System.out.println(i);
	}
		
	public static void println(boolean b) {
		System.out.println(b);
	}
	public static void println(double d) {
		System.out.println(d);
	}
	public static void println(String s) {
		System.out.println(s);
	}
	
}
