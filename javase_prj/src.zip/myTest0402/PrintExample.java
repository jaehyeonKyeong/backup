package myTest0402;

public class PrintExample {

	public static void main(String[] args) {
		
//		Printer printer = new Printer();
		Printer.println(10);
		Printer.println(true);
		Printer.println(5.7);
		Printer.println("ȫ�浿");
		
		

	}

}
