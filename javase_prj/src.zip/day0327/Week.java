package day0327;

public enum Week {
	MONDAY,
	THESDAY,
	WEDNESDAY,
	THURSDAY,
	FRIDAY,
	SATURDAY,
	SUNDAY
}
