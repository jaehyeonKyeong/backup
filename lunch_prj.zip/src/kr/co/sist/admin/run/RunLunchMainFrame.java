package kr.co.sist.admin.run;

import kr.co.sist.admin.view.TestLogin;

public class RunLunchMainFrame {

	public static void main(String[] args) {
		new TestLogin();
	}
	
}
